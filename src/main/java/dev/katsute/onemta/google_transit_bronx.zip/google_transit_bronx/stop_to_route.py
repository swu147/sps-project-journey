import csv
import collections

def ReadStopTimes():
  stop_times = []
  with open("stop_times.txt", "r") as f:
    reader = csv.DictReader(f)
    for r in reader:
      stop_times.append(r)
  return stop_times

def ReadStops():
  stops = {}
  with open("stops.txt", "r") as f:
    reader = csv.DictReader(f)
    for r in reader:
      stops[r["stop_id"]] = r
  return stops

def ReadTrips():
  trips = {}
  with open("trips.txt", "r") as f:
    reader = csv.DictReader(f)
    for r in reader:
      trips[r["trip_id"]] = r
  return trips

def ReadRoutes():
  routes = {}
  with open("routes.txt", "r") as f:
    reader = csv.DictReader(f)
    for r in reader:
      routes[r["route_id"]] = r
  return routes

def GetStopToRoutesMap(stop_times, trips):
  stop_to_routes = collections.defaultdict(set)
  for x in stop_times:
    trip = trips[x["trip_id"]]
    stop_to_routes[x["stop_id"]].add(trip["route_id"])
  return stop_to_routes

def main():
  stop_times = ReadStopTimes()
  stops = ReadStops()
  trips = ReadTrips()
  routes = ReadRoutes()

  stop_to_routes = GetStopToRoutesMap(stop_times, trips)

  res = collections.defaultdict(str)
  for k in stop_to_routes.keys():
      for v in stop_to_routes[k]:
          res[k] += str(v) + " "

  with open("stops.txt") as rFile, \
        open('stop_to_route.txt', 'wt', newline = '') as wFile:
    csv_reader = csv.reader(rFile)
    csv_writer = csv.writer(wFile)

    for row in csv_reader:
        row.append(res[row[0]])
        csv_writer.writerow(row)


if __name__ == "__main__":
  main()
